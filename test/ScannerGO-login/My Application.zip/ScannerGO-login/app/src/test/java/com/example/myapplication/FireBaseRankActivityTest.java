package com.example.myapplication;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.SdkSuppress;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class FirebaseRankActivityTest {
    @SdkSuppress(minSdkVersion = Build.VERSION_CODES.KITKAT)
    @Test
    public void testBackButton() {
        // 启动 Activity
        ActivityScenario<FirebaseRankActivity> scenario = ActivityScenario.launch(FirebaseRankActivity.class);

        // 模拟点击返回按钮
        scenario.onActivity(new ActivityScenario.ActivityAction<FirebaseRankActivity>() {
            @Override
            public void perform(FirebaseRankActivity activity) {
                Button backButton = activity.findViewById(R.id.back_button);
                backButton.performClick();
            }
        });

        // 检查是否启动了正确的 Activity
        scenario.onActivity(new ActivityScenario.ActivityAction<FirebaseRankActivity>() {
            @Override
            public void perform(FirebaseRankActivity activity) {
                Intent actualIntent = activity.getIntent();
                Intent expectedIntent = new Intent(activity, InMyRankActivity.class);
                assertTrue(actualIntent.filterEquals(expectedIntent));
                assertTrue(activity.isFinishing());
            }
        });
    }
}
