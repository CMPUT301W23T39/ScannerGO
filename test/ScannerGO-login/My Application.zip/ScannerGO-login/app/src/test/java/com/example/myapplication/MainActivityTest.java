package com.example.myapplication;

import android.content.Intent;
import android.widget.Button;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.matcher.ViewMatchers;

import org.junit.Test;

import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

public class MainActivityTest {

    @Test
    public void testButtons() {
        ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class);

        // Check if the Scan button is displayed and clickable
        Espresso.onView(ViewMatchers.withId(R.id.Scan))
                .check(matches(isDisplayed()))
                .perform(ViewActions.click());

        // Check if the ScanAction activity is launched
        Espresso.onView(withText("ScanAction activity"))
                .check(matches(isDisplayed()));

        // Press the Back button to return to MainActivity
        Espresso.pressBack();

        // Check if the Account button is displayed and clickable
        Espresso.onView(ViewMatchers.withId(R.id.Account))
                .check(matches(isDisplayed()))
                .perform(ViewActions.click());

        // Check if the InMyAccountActivity activity is launched
        Espresso.onView(withText("InMyAccountActivity activity"))
                .check(matches(isDisplayed()));

        // Press the Back button to return to MainActivity
        Espresso.pressBack();

        // Check if the Rank button is displayed and clickable
        Espresso.onView(ViewMatchers.withId(R.id.Rank))
                .check(matches(isDisplayed()))
                .perform(ViewActions.click());

        // Check if the InMyRankActivity activity is launched
        Espresso.onView(withText("InMyRankActivity activity"))
                .check(matches(isDisplayed()));

        // Press the Back button to return to MainActivity
        Espresso.pressBack();

        // Check if the Map button is displayed and clickable
        Espresso.onView(ViewMatchers.withId(R.id.Map))
                .check(matches(isDisplayed()))
                .perform(ViewActions.click());

        // Check if the map activity is launched
        Espresso.onView(withText("Map activity"))
                .check(matches(isDisplayed()));

        // Press the Back button to return to MainActivity
        Espresso.pressBack();

        // Check if MainActivity is displayed
        Espresso.onView(ViewMatchers.withId(R.id.mainActivity))
                .check(matches(isDisplayed()));

        scenario.close();
    }
}
