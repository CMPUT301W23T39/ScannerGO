package com.example.myapplication;

import android.view.View;
import android.widget.Button;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.rules.ActivityScenarioRule;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MyQRActivityTest {

    @Rule
    public ActivityScenarioRule<MyQRActivity> activityScenarioRule = new ActivityScenarioRule<>(MyQRActivity.class);

    private FirebaseFirestore db;
    private CollectionReference userCollection;
    private DocumentReference userDocRef;
    private CollectionReference qrCodesCollection;

    @Before
    public void setUp() {
        db = mock(FirebaseFirestore.class);
        userCollection = mock(CollectionReference.class);
        userDocRef = mock(DocumentReference.class);
        qrCodesCollection = mock(CollectionReference.class);

        when(db.collection("username")).thenReturn(userCollection);
        when(userCollection.document("1234")).thenReturn(userDocRef);
        when(userDocRef.collection("QR Codes")).thenReturn(qrCodesCollection);
    }

    @Test
    public void testDeleteButtonClick() {
        ActivityScenario<MyQRActivity> scenario = activityScenarioRule.getScenario();
        scenario.onActivity(activity -> {
            Button deleteButton = activity.findViewById(R.id.delete_button);
            String qrCode = "someQRCode";

            // Mock the result of the qrCodesCollection.get() method
            Query query = mock(Query.class);
            QueryDocumentSnapshot document = mock(QueryDocumentSnapshot.class);
            Map<String, Object> data = new HashMap<>();
            data.put("Name", qrCode);
            when(document.getString("Name")).thenReturn(qrCode);
            when(document.getReference()).thenReturn(mock(DocumentReference.class));
            when(query.get()).thenReturn(mock(com.google.android.gms.tasks.Task.class));
            when(query.get().getResult()).thenReturn(new QueryDocumentSnapshot[]{document});
            when(qrCodesCollection.get()).thenReturn(query);

            // Perform click on delete button
            deleteButton.performClick();

            // Verify that the qrCodesCollection.get() method was called
            verify(qrCodesCollection).get();

            // Verify that the document was deleted
            verify(document.getReference()).delete();

            // Verify that the QRListActivity was started and this activity was finished
            verify(activity).startActivity(mock(Intent.class));
            verify(activity).finish();

            // Check that the QR code name is no longer displayed on the screen
            activity.findViewById(R.id.qrcode_name).check(matches(not(isDisplayed())));
        });
    }
}
