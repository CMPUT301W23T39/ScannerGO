package com.example.myapplication;

import android.content.Intent;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(RobolectricTestRunner.class)
public class InMyAccountActivityTest {

    @Test
    public void backButtonNavigatesToMainActivity() {
        ActivityController<InMyAccountActivity> controller = Robolectric.buildActivity(InMyAccountActivity.class);
        InMyAccountActivity activity = controller.get();

        assertNotNull(activity.findViewById(R.id.back_button));
        activity.findViewById(R.id.back_button).performClick();

        Intent expectedIntent = new Intent(activity, MainActivity.class);
        Intent actualIntent = shadowOf(activity).getNextStartedActivity();
        assertEquals(expectedIntent.getComponent(), actualIntent.getComponent());
    }

    @Test
    public void profileButtonNavigatesToProfileActivity() {
        ActivityController<InMyAccountActivity> controller = Robolectric.buildActivity(InMyAccountActivity.class);
        InMyAccountActivity activity = controller.get();

        assertNotNull(activity.findViewById(R.id.profile_button));
        activity.findViewById(R.id.profile_button).performClick();

        Intent expectedIntent = new Intent(activity, ProfileActivity.class);
        Intent actualIntent = shadowOf(activity).getNextStartedActivity();
        assertEquals(expectedIntent.getComponent(), actualIntent.getComponent());
    }

    @Test
    public void QRListButtonNavigatesToQRListActivity() {
        ActivityController<InMyAccountActivity> controller = Robolectric.buildActivity(InMyAccountActivity.class);
        InMyAccountActivity activity = controller.get();

        assertNotNull(activity.findViewById(R.id.QRList_button));
        activity.findViewById(R.id.QRList_button).performClick();

        Intent expectedIntent = new Intent(activity, QRListActivity.class);
        Intent actualIntent = shadowOf(activity).getNextStartedActivity();
        assertEquals(expectedIntent.getComponent(), actualIntent.getComponent());
    }
}
