package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ProfileActivityTest {

    private ProfileActivity profileActivity;

    @Mock
    private Button backButton;

    @Mock
    private Button editButton;

    @Mock
    private TextView contactText;

    @Mock
    private TextView userText;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        profileActivity = Mockito.spy(new ProfileActivity());
        when(profileActivity.findViewById(R.id.back_button3)).thenReturn(backButton);
        when(profileActivity.findViewById(R.id.edit_button)).thenReturn(editButton);
        when(profileActivity.findViewById(R.id.contact_text)).thenReturn(contactText);
        when(profileActivity.findViewById(R.id.username_text)).thenReturn(userText);
    }

    @Test
    public void testEditButtonOnClick() {
        AlertDialog.Builder mockBuilder = Mockito.mock(AlertDialog.Builder.class);
        AlertDialog.Builder mockBuilder2 = Mockito.mock(AlertDialog.Builder.class);
        AlertDialog mockDialog = Mockito.mock(AlertDialog.class);
        EditText mockEditText = Mockito.mock(EditText.class);

        when(mockBuilder.setMessage(Mockito.anyString())).thenReturn(mockBuilder);
        when(mockBuilder.setPositiveButton(Mockito.anyString(), Mockito.any(DialogInterface.OnClickListener.class)))
                .thenReturn(mockBuilder);
        when(mockBuilder.setNegativeButton(Mockito.anyString(), Mockito.any(DialogInterface.OnClickListener.class)))
                .thenReturn(mockBuilder);
        when(mockBuilder.create()).thenReturn(mockDialog);

        when(mockBuilder2.setTitle(Mockito.anyString())).thenReturn(mockBuilder2);
        when(mockBuilder2.setView(Mockito.any(EditText.class))).thenReturn(mockBuilder2);
        when(mockBuilder2.setNegativeButton(Mockito.anyString(), Mockito.any(DialogInterface.OnClickListener.class)))
                .thenReturn(mockBuilder2);
        when(mockBuilder2.setPositiveButton(Mockito.anyString(), Mockito.any(DialogInterface.OnClickListener.class)))
                .thenReturn(mockBuilder2);

        Mockito.doReturn(mockBuilder2).when(mockBuilder).setPositiveButton(Mockito.anyString(),
                Mockito.any(DialogInterface.OnClickListener.class));
        Mockito.doReturn(mockBuilder2).when(mockBuilder).show();

        editButton.performClick();

        verify(mockBuilder).show();
        verify(mockBuilder2).show();

        Mockito.doReturn("mock user input").when(mockEditText).getText().toString();

        DialogInterface.OnClickListener listener = Mockito.mock(DialogInterface.OnClickListener.class);
        Mockito.doReturn(listener).when(mockBuilder2).create();
        listener.onClick(mockDialog, DialogInterface.BUTTON_POSITIVE);

        verify(contactText).setText("mock user input");
    }

    @Test
    public void testBackButtonOnClick() {
        Intent mockIntent = Mockito.mock(Intent.class);
        Mockito.doReturn(mockIntent).when(profileActivity).getIntent();
        backButton.performClick();
        verify(profileActivity).startActivity(mockIntent);
        verify(profileActivity).finish();
    }
}
