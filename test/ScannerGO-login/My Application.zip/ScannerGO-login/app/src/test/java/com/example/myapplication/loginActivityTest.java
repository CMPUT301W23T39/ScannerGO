package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.provider.Settings;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(AndroidJUnit4.class)
public class LoginButtonTest {

    @Rule
    public ActivityScenarioRule<loginActivity> activityScenarioRule =
            new ActivityScenarioRule<>(loginActivity.class);

    @Before
    public void setUp() {
        // Set up a mock Android ID
        Context context = ApplicationProvider.getApplicationContext();
        Resources resources = mock(Resources.class);
        when(resources.getString(com.google.android.gms.R.string.common_google_play_services_unknown_issue))
                .thenReturn("unknown");
        when(context.getResources()).thenReturn(resources);
        Settings.Secure.putString(context.getContentResolver(),
                Settings.Secure.ANDROID_ID, "mockAndroidId");
        // Initialize Firebase
        FirebaseApp.initializeApp(context);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference usersCollection = db.collection("username");
        // Create a test user
        Map<String, Object> testUser = new HashMap<>();
        testUser.put("userNameKey", "testUser");
        testUser.put("passwordKey", "testPassword");
        usersCollection.document("testUser").set(testUser);
    }

    @Test
    public void loginButton_withValidCredentials_navigatesToMainActivity() {
        // Perform login with valid credentials
        Espresso.onView(ViewMatchers.withId(R.id.usernameEditText))
                .perform(ViewActions.typeText("testUser"));
        Espresso.onView(ViewMatchers.withId(R.id.passwordEditText))
                .perform(ViewActions.typeText("testPassword"));
        Espresso.onView(ViewMatchers.withId(R.id.loginButton))
                .perform(ViewActions.click());
        // Check that MainActivity is launched
        Intent expectedIntent = new Intent(activityScenarioRule.getScenario().getApplicationContext(),
                MainActivity.class);
        activityScenarioRule.getScenario().onActivity(activity ->
                assertThat(activity.getLastStartedActivity(), equalTo(expectedIntent)));
    }
}
