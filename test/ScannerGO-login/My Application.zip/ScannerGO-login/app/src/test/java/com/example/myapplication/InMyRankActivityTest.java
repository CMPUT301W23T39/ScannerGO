package com.example.myapplication;

import android.content.Intent;
import android.widget.Button;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class InMyRankActivityTest {

    @Rule
    public ActivityScenarioRule<InMyRankActivity> activityScenarioRule =
            new ActivityScenarioRule<>(InMyRankActivity.class);

    @Test
    public void backButtonClick_shouldStartMainActivity() {
        // Click on the Back button
        Espresso.onView(ViewMatchers.withId(R.id.back_button))
                .perform(ViewActions.click());

        // Get the current activity scenario
        ActivityScenario<MainActivity> scenario = ActivityScenario.getScenario();

        // Verify that MainActivity was started
        scenario.onActivity(activity -> {
            Intent intent = activity.getIntent();
            Assert.assertEquals(MainActivity.class.getName(), intent.getComponent().getClassName());
        });
    }

    @Test
    public void firebaseButtonClick_shouldStartFireBaseRankActivity() {
        // Click on the Firebase button
        Espresso.onView(ViewMatchers.withId(R.id.firebase_button))
                .perform(ViewActions.click());

        // Get the current activity scenario
        ActivityScenario<FireBaseRankActivity> scenario = ActivityScenario.getScenario();

        // Verify that FireBaseRankActivity was started
        scenario.onActivity(activity -> {
            Intent intent = activity.getIntent();
            Assert.assertEquals(FireBaseRankActivity.class.getName(), intent.getComponent().getClassName());
        });
    }
}
