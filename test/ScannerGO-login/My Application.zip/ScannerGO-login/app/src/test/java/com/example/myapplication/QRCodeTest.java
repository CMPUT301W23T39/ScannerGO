package com.example.myapplication;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import com.example.myapplication.QRCode.Comment;

import static org.junit.Assert.*;

public class QRCodeTest {

    private QRCode qrCode;

    @Before
    public void setUp() {
        qrCode = new QRCode("hash", "codeName", "visualization", 5);
    }

    @Test
    public void testComment() {
        String username = "John";
        Date date = new Date();
        String content = "This is a comment.";
        qrCode.comment(username, date, content);
        ArrayList<Comment> comments = qrCode.getComments();
        assertEquals(1, comments.size());
        Comment comment = comments.get(0);
        assertEquals(username, comment.getUsername());
        assertEquals(date, comment.getDate());
        assertEquals(content, comment.getContent());
    }

    @Test
    public void testAddScanner() {
        String username = "Jane";
        String imageLink = "http://example.com/image.jpg";
        Date scannedDate = new Date();
        qrCode.addScanner(username, imageLink, scannedDate);
        ArrayList<QRCode.ScannerInfo> scannerInfoList = qrCode.getScannersInfo();
        assertEquals(1, scannerInfoList.size());
        QRCode.ScannerInfo scannerInfo = scannerInfoList.get(0);
        assertEquals(username, scannerInfo.getUsername());
        assertEquals(imageLink, scannerInfo.getImageLink());
        assertEquals(scannedDate, scannerInfo.getScannedDate());
    }

    @Test
    public void testGetters() {
        assertEquals("hash", qrCode.getHashValue());
        assertEquals("codeName", qrCode.getCodeName());
        assertEquals("visualization", qrCode.getVisualization());
        assertEquals(5, qrCode.getScore());
        assertEquals(0, qrCode.getTimesScanned());
    }
}
