package com.example.myapplication;

import com.google.android.gms.maps.model.LatLng;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import java.util.Map;

import static org.junit.Assert.*;
import com.google.android.gms.maps.GoogleMap;

class MapTest {

    private GoogleMap map;

    @Before
    public void setUp() {
        // TODO: Initialize the map object here
    }

    @Test
    public void testGetUserLocation() {
        // Expected latitude and longitude values
        double expectedLat = 37.4220936;
        double expectedLng = -122.083922;

        // Call the getUserLocation() method
        // TODO: Call the getUserLocation() method on the map object

        // Check if the latLngList contains a LatLng object with the expected values
        ArrayList<LatLng> latLngList = new ArrayList<>();
        // TODO: Get the latLngList from the map object
        boolean containsLatLng = false;
        for (LatLng latLng : latLngList) {
            if (latLng.latitude == expectedLat && latLng.longitude == expectedLng) {
                containsLatLng = true;
                break;
            }
        }
        assertTrue(containsLatLng);
    }
}
