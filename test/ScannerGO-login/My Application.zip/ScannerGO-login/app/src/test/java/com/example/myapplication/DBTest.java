package com.example.myapplication;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class DBTest {

    private FirebaseFirestore db;
    private CollectionReference collectionReferenceQR;

    @Before
    public void setUp() throws Exception {
        db = FirebaseFirestore.getInstance();
        DB.setDB(db);
        collectionReferenceQR = DB.getCollectionReferenceQR();
    }

    @Test

    public void delQRCodeInDB_deletesDocument() {
        // Add a document to the collection

        QRCode qrCode = new QRCode("hashValue", "codeName", "visualization", 0);
        collectionReferenceQR.document(qrCode.getHashValue()).set(qrCode);

        // Call the method to delete the document
        DB.delQRCodeInDB(qrCode.getHashValue());

        // Check if the document was deleted
        collectionReferenceQR.document(qrCode.getHashValue()).get()
                .addOnSuccessListener(documentSnapshot -> {
                    assertFalse(documentSnapshot.exists());
                });
    }

    // Add more tests for other methods
}
